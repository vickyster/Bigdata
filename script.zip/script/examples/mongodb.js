print('Hello world!');
